import Foundation

/// Barcha foydalanuvchiga ko'rinadigan matnlar bir joyda.
/// Keyinchalik String Catalog (Localizable.xcstrings) ga o'tkazish oson bo'ladi.
///
/// Imlo: o'zbek lotin yozuvida "o'" va "g'" uchun ʻ (U+02BB) belgisi ishlatiladi.
/// Poppins'da bu belgi yo'q, iOS uni avtomatik ravishda tizim shriftidan oladi.
enum Strings {

    enum Tab {
        static let home          = "Bosh"
        static let letters       = "Harflar"
        static let numbers       = "Sonlar"
        static let pronunciation = "Talaffuz"
        static let parent        = "Ota-ona"
    }

    enum Screen {
        static let letters       = "Harf yozish"
        static let numbers       = "Son yozish"
        static let pronunciation = "Talaffuz murabbiyi"
        static let parent        = "Ota-ona paneli"
    }

    enum Home {
        static let greeting          = "Salom,"
        static let todayAchievement  = "Bugungi yutuq"
        static let noStreak          = "Bugun birinchi mashqni boshlaymiz!"

        static func streak(_ days: Int) -> String {
            "\(days) kun ketma-ket mashq qildingiz!"
        }
    }

    enum Module {
        static let lettersTitle           = "Harflar"
        static let numbersTitle           = "Sonlar"
        static let pronunciationTitle     = "Talaffuz Murabbiyi"
        static let writeListenSpeak       = "Yozish · Eshitish · Aytish"
        static let pronunciationSubtitle  = "AI nutq tahlili"
    }

    enum Mode {
        static let offline              = "Offline"
        static let online               = "Online"
        static let offlineAccessibility = "Internetsiz ishlaydi"
        static let onlineAccessibility  = "Internet kerak"
    }

    enum Accessibility {
        static let opensSection = "Boʻlimni ochadi"
    }

    enum Placeholder {
        static let comingSoon = "Bu boʻlim keyingi bosqichda qoʻshiladi."
    }

    /// 2-bosqich: Harflar bo'limi. Faqat iOS'da ishlatiladi (Android'da hozircha placeholder).
    enum Letters {
        static let gridTitle       = "Harflar"
        static let caseUpper       = "Bosh harf"
        static let caseLower       = "Kichik harf"
        static let soundChip       = "Bosing — tovushni eshiting"
        static let soundMissing    = "Bu harfning ovozi hali qoʻshilmagan"
        static let statToday       = "Bugun mashq"
        static let statLearned     = "Oʻrganilgan"
        static let noneLearned     = "–"
        static let restart         = "Qaytadan"
        static let next            = "Keyingi harf"
        static let backToList      = "Harflar roʻyxati"
        static let keepGoing       = "Harfning butun ustidan yuring"
        static let stayInside      = "Nuqtali chiziq ichida qoling"
        static let success1        = "Yaxshi! Yana bir bor urinib koʻring"
        static let success2        = "Juda yaxshi!"
        static let success3        = "Ajoyib! Juda chiroyli!"
        static let canvasHint      = "Barmoq bilan harfning nuqtali chizigʻi ustidan yuring"
        static let restartHint     = "Chizilganini oʻchirib, qaytadan boshlaydi"

        static func progress(_ learned: Int, of total: Int) -> String {
            "\(learned) / \(total) harf oʻrganildi"
        }

        static func canvasLabel(_ letter: String) -> String {
            "Yozish maydoni. Harf: \(letter)"
        }

        static func stars(_ count: Int) -> String {
            "\(count) yulduz"
        }

        static func tileLabel(_ letter: String, upperDone: Bool, lowerDone: Bool) -> String {
            let upper = upperDone ? "bosh harf yozilgan" : "bosh harf yozilmagan"
            let lower = lowerDone ? "kichik harf yozilgan" : "kichik harf yozilmagan"
            return "\(letter) harfi, \(upper), \(lower)"
        }
    }
}
